-- 向select_courses表插入数据
INSERT INTO select_courses VALUES(101,6001,90);
INSERT INTO select_courses VALUES(101,6003,87);
INSERT INTO select_courses VALUES(101,6008,80);
INSERT INTO select_courses VALUES(102,6001,75);
INSERT INTO select_courses VALUES(103,6001,93);
INSERT INTO select_courses VALUES(103,6010,85);
INSERT INTO select_courses VALUES(103,6008,70);
INSERT INTO select_courses VALUES(104,6004,87);
INSERT INTO select_courses VALUES(104,6007,85);
INSERT INTO select_courses VALUES(104,6010,80);
INSERT INTO select_courses VALUES(105,6006,90);
