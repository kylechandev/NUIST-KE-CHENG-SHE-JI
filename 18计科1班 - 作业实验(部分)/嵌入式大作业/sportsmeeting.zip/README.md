# sportsmeeting

#### 介绍
高校运动会管理系统

#### 软件架构
软件架构说明


#### 安装教程

1.  打开 release文件夹
2.  导入 sports_meeting.sql数据库文件
4.  修改数据库地址  账号密码
3.  项目打jar包 运行 sportsmeeting-0.0.1-SNAPSHOT.jar
4.  访问127.0.0.1.8081

#### 使用说明

1.  环境要求   mysql数据库    jdk或jre运行环境
2.  数据库地址修改
    源码内：
    在sportsmeeting\src\main\resources\application-dev.properties文件
    注意修改数据库地址 默认是192.168.100.3:3306......
    注意修改数据库地址 若是本机  默认mysql端口   修改为127.0.0.1:3306
    数据库账号密码等
    jar包内：
    打开\BOOT-INF\classes\application-dev.properties文件夹  同上
3. shiro的权限只配置了页面显示，没权限不显示
    后台请求权限只配置了项目报名，没权限无法请求,想添加依次添加就行了

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 码云特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5.  码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
