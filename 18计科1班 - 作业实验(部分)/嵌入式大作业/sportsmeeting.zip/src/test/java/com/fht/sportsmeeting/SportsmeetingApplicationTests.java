package com.fht.sportsmeeting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsmeetingApplicationTests {

	@Test
	void contextLoads() {

	}

}
