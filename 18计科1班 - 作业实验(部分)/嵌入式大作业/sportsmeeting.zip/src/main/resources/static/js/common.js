
document.write(" <meta name=\"description\" content=\"基于Web的高校运动会管理系统\">\n" +
    "<meta name=\"keywords\" content=\"毕业设计,运动会,HTML,CSS,XML,JavaScript\">\n" +
    "<meta name=\"author\" content=\"fanhaiteng\">" +
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
    "    <link rel=\"stylesheet\" href=\"../static/vendor/bootstrap-3.3.7/css/bootstrap.css\">\n" +
    "    <link rel=\"stylesheet\" href=\"../static/vendor/font-awesome-4.7.0/css/font-awesome.min.css\">\n" +
    "    <script src=\"../static/vendor/jquery/jquery-3.4.1.min.js\"></script>\n" +
    "    <script src=\"../static/vendor/bootstrap-3.3.7/js/bootstrap.js\"></script>\n" +
    "    <link rel=\"shortcut icon\" href=\"../static/favicon.ico\"> \n" +
    "    <link rel=\"stylesheet\" href=\"../static/css/common.css\">")