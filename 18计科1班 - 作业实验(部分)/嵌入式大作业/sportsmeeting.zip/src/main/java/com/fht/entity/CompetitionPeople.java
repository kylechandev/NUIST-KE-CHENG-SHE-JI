package com.fht.entity;

import lombok.Data;

@Data
public class CompetitionPeople {
    String competitionName;
    String people;

}
