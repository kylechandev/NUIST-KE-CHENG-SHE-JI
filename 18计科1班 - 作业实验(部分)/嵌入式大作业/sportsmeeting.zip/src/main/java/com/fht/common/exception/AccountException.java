package com.fht.common.exception;


public class AccountException extends RuntimeException {

    public AccountException(String msg) {
        super(msg);
    }


}