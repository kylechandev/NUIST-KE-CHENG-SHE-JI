package com.fht.entity;

import lombok.Data;

@Data
public class TeamPeople {
    String team;
    String people;


}
