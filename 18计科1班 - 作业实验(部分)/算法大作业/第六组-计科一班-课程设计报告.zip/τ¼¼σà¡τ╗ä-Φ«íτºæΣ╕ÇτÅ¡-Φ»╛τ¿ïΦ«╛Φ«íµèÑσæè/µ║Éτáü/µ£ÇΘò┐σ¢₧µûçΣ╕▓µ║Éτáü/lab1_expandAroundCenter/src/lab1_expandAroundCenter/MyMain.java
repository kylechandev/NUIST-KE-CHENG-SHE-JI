package lab1_expandAroundCenter;


public class MyMain {
	public static void main(String[] args) {
        Solution sol=new Solution();
        String s;
        s=sol.longestPalindrome("aababaaa");
        System.out.println(s);
    }


}
