package courseSystem;

import java.sql.SQLException;

public class Test {
	public static void main(String[] args) throws SQLException {
        Login login=new Login();
        System.out.println("1");
        login.showMe();
    }

}
